from django.shortcuts import render, redirect
import random
def index(request):
    if "gold" not in request.session:
        request.session['gold']=0
        request.session['score']=0
        request.session['bankrupt']='hide'
        request.session['stopme']=False
    return render(request,'goldactivity/index.html')
def farm(request):
    if "gold" not in request.session:
        request.session['gold']=0
    if "score" not in request.session:
        request.session['score']=0
    if request.method == "POST":
        request.session['gold'] = random.randrange (10,20,1)
        request.session['score'] += request.session['gold']
    if request.session['score'] <0:
        request.session['bankrupt']='unhide'
        request.session['stopme']=True
    return render(request,'goldactivity/index.html')
def house(request):
    if "gold" not in request.session:
        request.session['gold']=0
    if "score" not in request.session:
        request.session['score']=0
    if request.method == "POST":
        if request.session['bankrupt'] == 'hide':
            request.session['gold'] = random.randrange (2,5,1)
            request.session['score'] += request.session['gold']
    if request.session['score'] <0:
        request.session['bankrupt']='unhide'
        request.session['stopme']=True
    return render(request,'goldactivity/index.html')
def cave(request):
    if "gold" not in request.session:
        request.session['gold']=0
    if "score" not in request.session:
        request.session['score']=0
    if request.method == "POST":
        request.session['gold'] = random.randrange (5,10,1)
        request.session['score'] += request.session['gold']
    if request.session['score'] <0:
        request.session['bankrupt']='unhide'
        request.session['stopme']=True
    return render(request,'goldactivity/index.html')
def casino(request):
    if "gold" not in request.session:
        request.session['gold']=0
    if "score" not in request.session:
        request.session['score']=0
    if request.method == "POST":
        request.session['gold'] = random.randrange (-100,100,1)
        request.session['score'] += request.session['gold']
    if request.session['score'] <0:
        request.session['bankrupt']='unhide'
        request.session['stopme']=True
    return render(request,'goldactivity/index.html')
def bankrupt(request):
    request.session['bankrupt']='unhide'
    request.session['stopme']=True
    return render(request,'goldactivity/index.html')
def resetme(request):
    request.session.clear
    request.session['score'] = 0
    request.session['bankrupt']='hide'
    request.session['stopme']=False
    return render(request,'goldactivity/index.html')
