from django.apps import AppConfig


class GoldactivityConfig(AppConfig):
    name = 'goldactivity'
