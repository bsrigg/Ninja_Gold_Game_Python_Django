from django.apps import AppConfig


class GameAppConfig(AppConfig):
    name = 'game_app'
